# AI CLUB — build kit

This project is an early **manual-handoff MVP**, not the fully autonomous product described in the original specification.

## Implemented in the supplied source
- Local projects, participant lists and per-project roles.
- One configurable coordinator per project.
- Local Room database for projects, messages, agents and tasks.
- Coordinator prompts, task plan import, task dependencies, result import, review/revision flow (up to three revisions), and final-result prompt.
- Copy prompt / open installed AI app / paste response back.
- Conversation export and local message search.
- No API keys and no INTERNET permission.

## Not implemented in this MVP
- AI-to-AI automatic communication or automatic retrieval of answers from third-party apps.
- Accessibility automation, WorkManager background execution, notifications, pause/resume.
- Attachments, private agent-to-agent chat, full backup/restore.
- Live AI connection status beyond checking whether selected apps are installed.

The AI apps do not expose a universal supported Android interface for sending prompts and reading answers. This build therefore uses an explicit manual hand-off. It does not bypass sign-in, paid tiers, CAPTCHA or app security.

## Build APK with GitHub Actions (phone-friendly)
1. Create a GitHub repository.
2. Upload `AICLUB-src.zip` to the repository root.
3. Upload `.github/workflows/build.yml` from this kit to the same path in the repository.
4. Commit the files. Open the repository's **Actions** tab.
5. Open the workflow run named **Build and test AI CLUB APK**. Wait until it finishes successfully.
6. Open the run's **Artifacts** section and download `AICLUB-debug-apk`.
7. Extract the downloaded artifact and install the `.apk` on Android. Android may ask you to allow installation from that file manager/browser.

The workflow runs the unit tests before building. A failed test or build fails the workflow; it will not silently mark a failed test as successful.

## Build locally
Requirements: Android Studio with Android SDK Platform 34, JDK 17, and Gradle 8.9. Extract `AICLUB-src.zip`, open `AICLUB/` in Android Studio, then run `testDebugUnitTest` and `assembleDebug`.

APK output: `AICLUB/app/build/outputs/apk/debug/app-debug.apk`.

## Honest status
The uploaded environment for this task does not contain Android SDK Platform / build-tools or a usable Gradle installation, so an APK could not be compiled or installed here. The source was inspected and the build workflow was corrected, but compilation and device runtime tests remain **unverified** until the GitHub Actions build (or a local Android Studio build) completes.
