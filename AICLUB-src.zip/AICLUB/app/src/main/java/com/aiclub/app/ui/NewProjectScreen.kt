@file:OptIn(ExperimentalMaterial3Api::class)

package com.aiclub.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.aiclub.app.data.ClubRepository
import com.aiclub.app.logic.KNOWN_APPS

@Composable
fun NewProjectScreen(vm: ClubViewModel, onCancel: () -> Unit, onCreated: (Long) -> Unit) {
    var name by rememberSaveable { mutableStateOf("") }
    var objective by rememberSaveable { mutableStateOf("") }
    var coordKey by rememberSaveable { mutableStateOf("chatgpt") }
    var otherName by rememberSaveable { mutableStateOf("") }
    val selected = remember { mutableStateMapOf("chatgpt" to true, "claude" to true) }
    val roles = remember {
        mutableStateMapOf<String, String>().also { m -> KNOWN_APPS.forEach { m[it.key] = it.defaultRole } }
    }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onCancel) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") }
            Text("New project", style = MaterialTheme.typography.headlineSmall)
        }
        OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Project name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = objective, onValueChange = { objective = it }, label = { Text("Objective") }, minLines = 3, modifier = Modifier.fillMaxWidth())
        Text("Participants: tick who joins, pick one coordinator, set each role.", style = MaterialTheme.typography.titleSmall)
        KNOWN_APPS.forEach { app ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(
                            checked = selected[app.key] == true,
                            onCheckedChange = {
                                selected[app.key] = it
                                if (!it && coordKey == app.key) coordKey = ""
                            }
                        )
                        Text(app.label, modifier = Modifier.weight(1f))
                        RadioButton(selected = coordKey == app.key, onClick = { selected[app.key] = true; coordKey = app.key })
                        Text("Coordinator", style = MaterialTheme.typography.labelSmall)
                    }
                    if (selected[app.key] == true) {
                        if (app.key == "other") {
                            OutlinedTextField(value = otherName, onValueChange = { otherName = it }, label = { Text("App name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                        }
                        OutlinedTextField(
                            value = roles[app.key] ?: "",
                            onValueChange = { roles[app.key] = it },
                            label = { Text("Role (Researcher, Scriptwriter, Reviewer...)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            }
        }
        Text(
            "Autonomy: manual-assist. You copy tasks between apps; the coordinator's decisions are applied automatically. Fully automatic modes are not available in this build.",
            style = MaterialTheme.typography.bodySmall
        )
        Button(
            onClick = {
                val members = KNOWN_APPS.filter { selected[it.key] == true }.map {
                    ClubRepository.NewMember(
                        it.key,
                        if (it.key == "other") otherName.ifBlank { "Other AI" } else it.label,
                        roles[it.key].orEmpty().ifBlank { it.defaultRole }
                    )
                }
                val idx = members.indexOfFirst { it.appKey == coordKey }
                vm.createProject(name, objective, members, idx, onCreated)
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("Create project room") }
    }
}
