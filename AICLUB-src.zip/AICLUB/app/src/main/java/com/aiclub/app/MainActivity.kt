package com.aiclub.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.List
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.lifecycle.viewmodel.compose.viewModel
import com.aiclub.app.ui.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AiClubTheme { AppRoot() } }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppRoot(vm: ClubViewModel = viewModel()) {
    var roomId by rememberSaveable { mutableStateOf<Long?>(null) }
    var creating by rememberSaveable { mutableStateOf(false) }
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(Unit) { vm.toast.collect { snackbar.showSnackbar(it) } }
    BackHandler(enabled = roomId != null || creating) {
        if (creating) creating = false else roomId = null
    }
    val currentRoom = roomId
    Scaffold(
        snackbarHost = { SnackbarHost(snackbar) },
        bottomBar = { if (currentRoom == null && !creating) NavBar(tab) { tab = it } }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when {
                creating -> NewProjectScreen(vm, onCancel = { creating = false }, onCreated = { creating = false; roomId = it })
                currentRoom != null -> RoomScreen(vm, currentRoom, onBack = { roomId = null })
                else -> when (tab) {
                    0 -> ProjectsScreen(vm, onOpen = { roomId = it }, onCreate = { creating = true })
                    1 -> AgentsScreen()
                    2 -> TasksScreen(vm, onOpen = { roomId = it })
                    3 -> ActivityScreen(vm, onOpen = { roomId = it })
                    else -> SettingsScreen()
                }
            }
        }
    }
}

@Composable
private fun NavBar(selected: Int, onSelect: (Int) -> Unit) {
    val items: List<Pair<String, ImageVector>> = listOf(
        "Projects" to Icons.Default.Home,
        "Agents" to Icons.Default.Person,
        "Tasks" to Icons.Default.CheckCircle,
        "Activity" to Icons.AutoMirrored.Filled.List,
        "Settings" to Icons.Default.Settings
    )
    NavigationBar {
        items.forEachIndexed { i, (label, icon) ->
            NavigationBarItem(
                selected = selected == i,
                onClick = { onSelect(i) },
                icon = { Icon(icon, contentDescription = label) },
                label = { Text(label) }
            )
        }
    }
}
