@file:OptIn(ExperimentalMaterial3Api::class)

package com.aiclub.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.aiclub.app.data.ProjectEntity
import com.aiclub.app.data.TaskStatus
import com.aiclub.app.logic.KNOWN_APPS
import java.text.DateFormat
import java.util.Date

@Composable
fun ProjectsScreen(vm: ClubViewModel, onOpen: (Long) -> Unit, onCreate: () -> Unit) {
    val projects by vm.projects.collectAsState()
    var deleting by remember { mutableStateOf<ProjectEntity?>(null) }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Projects", style = MaterialTheme.typography.headlineMedium)
        Button(onClick = onCreate, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Add, contentDescription = null)
            Spacer(Modifier.width(8.dp))
            Text("Create Project")
        }
        if (projects.isEmpty()) {
            Text("No projects yet. Create one, pick a coordinator and add the AI apps you use.", style = MaterialTheme.typography.bodyMedium)
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(projects, key = { it.id }) { p ->
                Card(onClick = { onOpen(p.id) }, modifier = Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(p.name, style = MaterialTheme.typography.titleMedium)
                            Text(p.objective, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Spacer(Modifier.height(4.dp))
                            Text(stageLabel(p.stage), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                        }
                        IconButton(onClick = { deleting = p }) { Icon(Icons.Default.Delete, contentDescription = "Delete project") }
                    }
                }
            }
        }
    }
    deleting?.let { p ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Delete \"${p.name}\"?") },
            text = { Text("This permanently deletes the project, its tasks and its conversation from this phone.") },
            confirmButton = {
                TextButton(onClick = {
                    vm.act { vm.repo.deleteProject(p.id) }
                    deleting = null
                }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Cancel") } }
        )
    }
}

@Composable
fun AgentsScreen() {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Agents", style = MaterialTheme.typography.headlineMedium)
        Text(
            "Real connection status of AI apps on this phone. Roles are set per project (open a project, then Team).",
            style = MaterialTheme.typography.bodySmall
        )
        KNOWN_APPS.filter { it.pkg != null }.forEach { app ->
            val installed = Launcher.isInstalled(ctx, app.pkg)
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(app.label, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                        StatusChip(if (installed) "Installed" else "Not installed")
                    }
                    Text(
                        if (installed) "Connection: manual hand-off (copy prompt, paste reply). Automatic reading of replies is not available in this build."
                        else "Not found on this phone. You can still paste its prompts into the website or another device.",
                        style = MaterialTheme.typography.bodySmall
                    )
                }
            }
        }
    }
}

@Composable
fun TasksScreen(vm: ClubViewModel, onOpen: (Long) -> Unit) {
    val tasks by vm.allTasks.collectAsState()
    val projects by vm.projects.collectAsState()
    val names = projects.associate { it.id to it.name }
    val active = setOf(TaskStatus.ASSIGNED, TaskStatus.AWAITING_RESPONSE, TaskStatus.IN_PROGRESS, TaskStatus.REQUIRES_REVISION)
    val groups = listOf(
        "Active" to tasks.filter { it.status in active },
        "Pending" to tasks.filter { it.status == TaskStatus.PENDING },
        "Errors" to tasks.filter { it.status == TaskStatus.FAILED },
        "Completed" to tasks.filter { it.status == TaskStatus.COMPLETED }
    )
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Tasks", style = MaterialTheme.typography.headlineMedium)
        if (tasks.isEmpty()) Text("No tasks yet. They appear when a coordinator's plan is imported.", style = MaterialTheme.typography.bodyMedium)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            groups.forEach { (label, list) ->
                if (list.isNotEmpty()) {
                    item(key = "header-$label") {
                        Text("$label (${list.size})", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 8.dp))
                    }
                    items(list, key = { it.id }) { t ->
                        Card(onClick = { onOpen(t.projectId) }, modifier = Modifier.fillMaxWidth()) {
                            Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(t.title, style = MaterialTheme.typography.titleSmall)
                                    Text(names[t.projectId] ?: "", style = MaterialTheme.typography.bodySmall)
                                }
                                StatusChip(statusLabel(t.status))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ActivityScreen(vm: ClubViewModel, onOpen: (Long) -> Unit) {
    var q by rememberSaveable { mutableStateOf("") }
    val messages by remember(q) { vm.dao.searchMessages(q) }.collectAsState(initial = emptyList())
    val df = remember { DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT) }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Activity", style = MaterialTheme.typography.headlineMedium)
        OutlinedTextField(value = q, onValueChange = { q = it }, label = { Text("Search all messages") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(messages, key = { it.id }) { m ->
                Card(onClick = { onOpen(m.projectId) }, modifier = Modifier.fillMaxWidth()) {
                    Column(Modifier.padding(12.dp)) {
                        Text("${m.senderName} - ${df.format(Date(m.createdAt))}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                        Text(m.text, style = MaterialTheme.typography.bodySmall, maxLines = 3, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen() {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineMedium)
        InfoCard("Permissions", "This build requests no permissions. It can only check whether the supported AI apps are installed.")
        InfoCard("Privacy", "The app has no internet access. Projects and conversations are stored only on this phone. Delete a project from the Projects tab to erase its history. Use the share button in a room to export a conversation.")
        InfoCard("Automation", "Accessibility automation and background execution are not implemented in this build. Everything runs through copy / paste hand-off, which works with any AI app.")
        InfoCard("Cost", "Every feature in this build is free. What the AI apps themselves allow depends on your own accounts and their limits. No APIs are used.")
    }
}

@Composable
private fun InfoCard(title: String, body: String) {
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            Text(body, style = MaterialTheme.typography.bodySmall)
        }
    }
}
