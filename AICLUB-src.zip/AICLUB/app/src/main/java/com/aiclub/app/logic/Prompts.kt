package com.aiclub.app.logic

import com.aiclub.app.data.AgentEntity
import com.aiclub.app.data.ProjectEntity
import com.aiclub.app.data.TaskEntity
import com.aiclub.app.data.TaskStatus
import com.aiclub.app.data.dependencyIds

/** Builds the texts the user copies into the AI apps. Pure functions, regenerated from saved state. */
object Prompts {

    private fun header(p: ProjectEntity) = "Project: \"${p.name}\"\nObjective: ${p.objective}"

    fun plan(p: ProjectEntity, agents: List<AgentEntity>, coordinator: AgentEntity, request: String): String = buildString {
        appendLine("You are \"${coordinator.name}\", the coordinator of an AI team.")
        appendLine(header(p))
        appendLine()
        appendLine("Team members:")
        agents.forEach { a ->
            val extra = if (a.instructions.isBlank()) "" else " - ${a.instructions}"
            appendLine("- ${a.name} (role: ${a.role})$extra")
        }
        appendLine()
        appendLine("User request:")
        appendLine(request)
        appendLine()
        appendLine("Split the request into subtasks and assign each to the best-suited member (you may assign tasks to yourself).")
        appendLine("Reply with ONLY one JSON object and nothing else, in exactly this shape:")
        appendLine("{\"summary\":\"short plan\",\"tasks\":[{\"title\":\"...\",\"description\":\"complete instructions for the assignee\",\"agent\":\"exact member name\",\"depends_on\":[]}]}")
        append("\"depends_on\" holds zero-based indexes of EARLIER tasks in the array whose results this task needs.")
    }

    fun forTask(p: ProjectEntity, agent: AgentEntity, task: TaskEntity, all: List<TaskEntity>, agents: List<AgentEntity>): String = buildString {
        appendLine("You are \"${agent.name}\", role: ${agent.role}, on an AI team.")
        appendLine(header(p))
        if (agent.instructions.isNotBlank()) appendLine("Standing instructions: ${agent.instructions}")
        appendLine()
        appendLine("YOUR TASK: ${task.title}")
        appendLine(task.description)
        val deps = task.dependencyIds()
            .mapNotNull { id -> all.firstOrNull { it.id == id } }
            .filter { it.result.isNotBlank() }
        if (agent.receivesSharedResults && deps.isNotEmpty()) {
            appendLine()
            appendLine("Results from teammates you may use:")
            deps.forEach { d ->
                val who = agents.firstOrNull { it.id == d.agentId }?.name ?: "teammate"
                appendLine("--- $who: ${d.title} ---")
                appendLine(d.result)
            }
            appendLine("--- end of teammate results ---")
        }
        if (task.revisionCount > 0 && task.revisionNote.isNotBlank() && task.status != TaskStatus.PENDING) {
            appendLine()
            appendLine("REVISION REQUESTED. Your previous answer was:")
            appendLine(task.result)
            appendLine("Coordinator feedback: ${task.revisionNote}")
        }
        appendLine()
        append("Reply with your complete result only.")
    }

    fun review(p: ProjectEntity, coordinator: AgentEntity, assignee: AgentEntity?, task: TaskEntity): String = buildString {
        appendLine("You are \"${coordinator.name}\", coordinator of an AI team. Review a teammate's result.")
        appendLine(header(p))
        appendLine()
        appendLine("Task: ${task.title}")
        appendLine(task.description)
        appendLine()
        appendLine("Result from ${assignee?.name ?: "the assignee"} (revision attempts so far: ${task.revisionCount}):")
        appendLine(task.result)
        appendLine()
        appendLine("Decide whether the result is good enough. Reply with ONLY one JSON object, either")
        appendLine("{\"verdict\":\"approve\",\"feedback\":\"\"}")
        appendLine("or")
        append("{\"verdict\":\"revise\",\"feedback\":\"what must be improved\"}")
    }

    fun finalResult(p: ProjectEntity, coordinator: AgentEntity, tasks: List<TaskEntity>, agents: List<AgentEntity>): String = buildString {
        appendLine("You are \"${coordinator.name}\", coordinator of an AI team. All subtasks are done.")
        appendLine(header(p))
        appendLine()
        appendLine("Original user request:")
        appendLine(p.currentRequest)
        appendLine()
        appendLine("Approved results from the team:")
        tasks.filter { it.status == TaskStatus.COMPLETED }.forEach { t ->
            val who = agents.firstOrNull { it.id == t.agentId }?.name ?: "teammate"
            appendLine("=== ${t.title} (by $who) ===")
            appendLine(t.result)
            appendLine()
        }
        append("Combine everything into ONE final deliverable for the user's request. Reply with the finished deliverable only.")
    }
}
