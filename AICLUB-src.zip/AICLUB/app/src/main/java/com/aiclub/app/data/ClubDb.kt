package com.aiclub.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [ProjectEntity::class, AgentEntity::class, MessageEntity::class, TaskEntity::class],
    version = 1,
    exportSchema = false
)
abstract class ClubDb : RoomDatabase() {
    abstract fun dao(): ClubDao

    companion object {
        @Volatile private var instance: ClubDb? = null

        fun get(context: Context): ClubDb = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(context.applicationContext, ClubDb::class.java, "aiclub.db")
                .build()
                .also { instance = it }
        }
    }
}
