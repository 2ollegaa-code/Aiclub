package com.aiclub.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ClubDao {
    @Query("SELECT * FROM projects ORDER BY createdAt DESC")
    fun observeProjects(): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects WHERE id = :id")
    fun observeProject(id: Long): Flow<ProjectEntity?>

    @Query("SELECT * FROM projects WHERE id = :id")
    suspend fun getProject(id: Long): ProjectEntity?

    @Insert
    suspend fun insertProject(p: ProjectEntity): Long

    @Update
    suspend fun updateProject(p: ProjectEntity)

    @Query("DELETE FROM projects WHERE id = :id")
    suspend fun deleteProject(id: Long)

    @Query("SELECT * FROM agents WHERE projectId = :pid ORDER BY id")
    fun observeAgents(pid: Long): Flow<List<AgentEntity>>

    @Query("SELECT * FROM agents WHERE projectId = :pid ORDER BY id")
    suspend fun getAgents(pid: Long): List<AgentEntity>

    @Query("SELECT * FROM agents WHERE id = :id")
    suspend fun getAgent(id: Long): AgentEntity?

    @Insert
    suspend fun insertAgent(a: AgentEntity): Long

    @Update
    suspend fun updateAgent(a: AgentEntity)

    @Query("DELETE FROM agents WHERE id = :id")
    suspend fun deleteAgent(id: Long)

    @Query("SELECT * FROM messages WHERE projectId = :pid ORDER BY createdAt, id")
    fun observeMessages(pid: Long): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages WHERE projectId = :pid ORDER BY createdAt, id")
    suspend fun getMessages(pid: Long): List<MessageEntity>

    @Query("SELECT * FROM messages WHERE text LIKE '%' || :q || '%' ORDER BY createdAt DESC LIMIT 200")
    fun searchMessages(q: String): Flow<List<MessageEntity>>

    @Insert
    suspend fun insertMessage(m: MessageEntity): Long

    @Query("SELECT * FROM tasks WHERE projectId = :pid ORDER BY id")
    fun observeTasks(pid: Long): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks ORDER BY createdAt DESC")
    fun observeAllTasks(): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE projectId = :pid ORDER BY id")
    suspend fun getTasks(pid: Long): List<TaskEntity>

    @Query("SELECT * FROM tasks WHERE id = :id")
    suspend fun getTask(id: Long): TaskEntity?

    @Insert
    suspend fun insertTask(t: TaskEntity): Long

    @Update
    suspend fun updateTask(t: TaskEntity)
}
