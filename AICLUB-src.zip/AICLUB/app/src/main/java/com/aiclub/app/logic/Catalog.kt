package com.aiclub.app.logic

data class KnownApp(val key: String, val label: String, val pkg: String?, val defaultRole: String)

val KNOWN_APPS = listOf(
    KnownApp("chatgpt", "ChatGPT", "com.openai.chatgpt", "Planner"),
    KnownApp("claude", "Claude", "com.anthropic.claude", "Writer"),
    KnownApp("perplexity", "Perplexity", "ai.perplexity.app.android", "Researcher"),
    KnownApp("gemini", "Gemini", "com.google.android.apps.bard", "Analyst"),
    KnownApp("other", "Other AI app", null, "Assistant")
)

fun knownApp(key: String): KnownApp = KNOWN_APPS.firstOrNull { it.key == key } ?: KNOWN_APPS.last()
