package com.aiclub.app.logic

import org.json.JSONException
import org.json.JSONObject

data class PlannedTask(val title: String, val description: String, val agent: String, val dependsOn: List<Int>)
data class Plan(val summary: String, val tasks: List<PlannedTask>)
data class Review(val approved: Boolean, val feedback: String)

sealed class ParseResult<out T> {
    data class Ok<T>(val value: T) : ParseResult<T>()
    data class Err(val message: String) : ParseResult<Nothing>()
}

object Parsers {
    /** AI replies often wrap JSON in prose or code fences; take the outermost {...}. */
    fun extractJson(raw: String): String? {
        val start = raw.indexOf('{')
        val end = raw.lastIndexOf('}')
        return if (start < 0 || end <= start) null else raw.substring(start, end + 1)
    }

    fun parsePlan(raw: String): ParseResult<Plan> {
        val json = extractJson(raw) ?: return ParseResult.Err("No JSON object found in the pasted text.")
        return try {
            val o = JSONObject(json)
            val arr = o.optJSONArray("tasks") ?: return ParseResult.Err("The JSON has no \"tasks\" list.")
            if (arr.length() == 0) return ParseResult.Err("The plan contains no tasks.")
            val tasks = ArrayList<PlannedTask>()
            for (i in 0 until arr.length()) {
                val t = arr.getJSONObject(i)
                val deps = ArrayList<Int>()
                val d = t.optJSONArray("depends_on")
                if (d != null) {
                    for (k in 0 until d.length()) deps.add(d.getInt(k))
                }
                for (dep in deps) {
                    if (dep < 0 || dep >= i) {
                        return ParseResult.Err("Task ${i + 1} depends on an invalid index ($dep). Dependencies must point to earlier tasks.")
                    }
                }
                tasks.add(
                    PlannedTask(
                        t.getString("title").trim(),
                        t.optString("description", "").trim(),
                        t.getString("agent").trim(),
                        deps
                    )
                )
            }
            ParseResult.Ok(Plan(o.optString("summary", "").trim(), tasks))
        } catch (e: JSONException) {
            ParseResult.Err("Invalid JSON: ${e.message}")
        }
    }

    fun parseReview(raw: String): ParseResult<Review> {
        val json = extractJson(raw) ?: return ParseResult.Err("No JSON object found in the pasted text.")
        return try {
            val o = JSONObject(json)
            val verdict = o.getString("verdict").trim().lowercase()
            val feedback = o.optString("feedback", "").trim()
            when {
                verdict.startsWith("approv") -> ParseResult.Ok(Review(true, feedback))
                verdict.startsWith("revis") -> ParseResult.Ok(Review(false, feedback.ifBlank { "Please improve the result." }))
                else -> ParseResult.Err("Unknown verdict \"$verdict\" (expected approve or revise).")
            }
        } catch (e: JSONException) {
            ParseResult.Err("Invalid JSON: ${e.message}")
        }
    }
}
