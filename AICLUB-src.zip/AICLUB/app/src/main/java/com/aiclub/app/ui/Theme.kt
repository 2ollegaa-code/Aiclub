package com.aiclub.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

@Composable
fun AiClubTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF8AB4FF),
            onPrimary = Color(0xFF00203F),
            primaryContainer = Color(0xFF1D3A63),
            onPrimaryContainer = Color(0xFFD6E4FF),
            secondary = Color(0xFF7FE3C4),
            secondaryContainer = Color(0xFF14473B),
            onSecondaryContainer = Color(0xFFCFF7EA),
            background = Color(0xFF0E1116),
            onBackground = Color(0xFFE6EAF0),
            surface = Color(0xFF151A21),
            onSurface = Color(0xFFE6EAF0),
            surfaceVariant = Color(0xFF1E252E),
            onSurfaceVariant = Color(0xFFC3CAD4)
        ),
        content = content
    )
}
