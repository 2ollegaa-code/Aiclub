@file:OptIn(ExperimentalMaterial3Api::class)

package com.aiclub.app.ui

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.aiclub.app.logic.KnownApp

@Composable
fun StatusChip(text: String) {
    Surface(shape = RoundedCornerShape(50), color = MaterialTheme.colorScheme.secondaryContainer) {
        Text(
            text,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSecondaryContainer
        )
    }
}

/**
 * The manual-handoff step: copy a prepared prompt (optionally opening the AI app),
 * then paste the AI's reply back and import it.
 */
@Composable
fun PromptStep(
    title: String,
    hint: String,
    prompt: String,
    app: KnownApp,
    importLabel: String,
    importButton: String,
    onCopied: () -> Unit = {},
    onSubmit: (text: String, onSuccess: () -> Unit) -> Unit
) {
    val ctx = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var text by remember { mutableStateOf("") }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            Text(hint, style = MaterialTheme.typography.bodySmall)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    Launcher.copy(ctx, prompt)
                    onCopied()
                    Toast.makeText(ctx, "Prompt copied", Toast.LENGTH_SHORT).show()
                }) { Text("Copy prompt") }
                Button(onClick = {
                    Launcher.copy(ctx, prompt)
                    onCopied()
                    if (!Launcher.open(ctx, app.pkg)) {
                        Toast.makeText(ctx, "Prompt copied. Open ${app.label} yourself and paste it.", Toast.LENGTH_LONG).show()
                    }
                }) { Text("Copy & open ${app.label}", maxLines = 1) }
            }
            OutlinedTextField(
                value = text,
                onValueChange = { text = it },
                label = { Text(importLabel) },
                modifier = Modifier.fillMaxWidth(),
                maxLines = 5
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { text = clipboard.getText()?.text ?: "" }) { Text("Paste") }
                Button(onClick = { onSubmit(text) { text = "" } }, enabled = text.isNotBlank()) { Text(importButton) }
            }
        }
    }
}
