package com.aiclub.app.ui

import com.aiclub.app.data.Stage
import com.aiclub.app.data.TaskStatus

fun stageLabel(s: Stage) = when (s) {
    Stage.IDLE -> "Ready for a task"
    Stage.AWAITING_PLAN -> "Waiting for the coordinator's plan"
    Stage.EXECUTING -> "Team is working"
    Stage.AWAITING_FINAL -> "Waiting for the final result"
    Stage.DONE -> "Finished"
}

fun statusLabel(s: TaskStatus) = when (s) {
    TaskStatus.PENDING -> "Pending"
    TaskStatus.ASSIGNED -> "Assigned"
    TaskStatus.AWAITING_RESPONSE -> "Awaiting response"
    TaskStatus.IN_PROGRESS -> "In review"
    TaskStatus.REQUIRES_REVISION -> "Requires revision"
    TaskStatus.COMPLETED -> "Completed"
    TaskStatus.FAILED -> "Failed"
}
