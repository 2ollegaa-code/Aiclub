package com.aiclub.app.data

import com.aiclub.app.logic.ParseResult
import com.aiclub.app.logic.Parsers

/**
 * Workflow state machine. All state lives in the database, so a restart loses nothing.
 * User-facing errors are thrown as IllegalArgumentException / IllegalStateException with readable messages.
 */
class ClubRepository(
    private val dao: ClubDao,
    private val now: () -> Long = { System.currentTimeMillis() }
) {
    data class NewMember(val appKey: String, val name: String, val role: String)

    // ---------- helpers ----------

    private fun String.plusLine(s: String) = if (isEmpty()) s else "$this\n$s"

    private fun uniqueName(base: String, used: MutableSet<String>): String {
        val clean = base.trim().ifBlank { "AI" }
        var candidate = clean
        var n = 2
        while (!used.add(candidate.lowercase())) {
            candidate = "$clean $n"
            n++
        }
        return candidate
    }

    private suspend fun project(pid: Long): ProjectEntity =
        dao.getProject(pid) ?: throw IllegalStateException("Project not found.")

    private suspend fun task(id: Long): TaskEntity =
        dao.getTask(id) ?: throw IllegalStateException("Task not found.")

    private suspend fun msg(pid: Long, kind: MessageKind, sender: String, text: String, taskId: Long? = null) {
        dao.insertMessage(MessageEntity(projectId = pid, kind = kind, senderName = sender, text = text, taskId = taskId, createdAt = now()))
    }

    private suspend fun system(pid: Long, text: String) = msg(pid, MessageKind.SYSTEM, "System", text)

    // ---------- projects & team ----------

    suspend fun createProject(name: String, objective: String, members: List<NewMember>, coordinatorIndex: Int): Long {
        require(name.isNotBlank()) { "Enter a project name." }
        require(members.isNotEmpty()) { "Select at least one participant." }
        require(coordinatorIndex in members.indices) { "Choose a coordinator among the selected participants." }
        val pid = dao.insertProject(ProjectEntity(name = name.trim(), objective = objective.trim(), createdAt = now()))
        val used = mutableSetOf<String>()
        val ids = ArrayList<Long>()
        val names = ArrayList<String>()
        for (m in members) {
            val unique = uniqueName(m.name, used)
            names.add(unique)
            ids.add(dao.insertAgent(AgentEntity(projectId = pid, appKey = m.appKey, name = unique, role = m.role.ifBlank { "Assistant" })))
        }
        dao.updateProject(project(pid).copy(coordinatorAgentId = ids[coordinatorIndex]))
        system(pid, "Project created. Coordinator: ${names[coordinatorIndex]}. Team: ${names.joinToString()}.")
        return pid
    }

    suspend fun deleteProject(pid: Long) = dao.deleteProject(pid)

    suspend fun addAgent(pid: Long, m: NewMember): Long {
        project(pid)
        val used = dao.getAgents(pid).map { it.name.lowercase() }.toMutableSet()
        val name = uniqueName(m.name, used)
        val id = dao.insertAgent(AgentEntity(projectId = pid, appKey = m.appKey, name = name, role = m.role.ifBlank { "Assistant" }))
        system(pid, "$name joined the team.")
        return id
    }

    suspend fun removeAgent(agentId: Long) {
        val a = dao.getAgent(agentId) ?: return
        val p = project(a.projectId)
        check(p.coordinatorAgentId != agentId) { "Change the coordinator before removing ${a.name}." }
        dao.getTasks(p.id)
            .filter { it.agentId == agentId && it.status != TaskStatus.COMPLETED }
            .forEach {
                dao.updateTask(it.copy(agentId = p.coordinatorAgentId, history = it.history.plusLine("Reassigned to the coordinator (agent removed).")))
            }
        dao.deleteAgent(agentId)
        system(p.id, "${a.name} left the team.")
    }

    suspend fun setCoordinator(pid: Long, agentId: Long) {
        val a = dao.getAgent(agentId)?.takeIf { it.projectId == pid } ?: throw IllegalArgumentException("Unknown participant.")
        dao.updateProject(project(pid).copy(coordinatorAgentId = agentId))
        system(pid, "${a.name} is now the coordinator.")
    }

    suspend fun updateAgent(a: AgentEntity) = dao.updateAgent(a)

    // ---------- request -> plan ----------

    suspend fun submitRequest(pid: Long, text: String) {
        require(text.isNotBlank()) { "Write the task first." }
        val p = project(pid)
        check(p.stage == Stage.IDLE || p.stage == Stage.DONE) { "A request is already in progress." }
        val coord = dao.getAgent(p.coordinatorAgentId) ?: throw IllegalStateException("The project has no coordinator.")
        msg(pid, MessageKind.USER, "You", text.trim())
        dao.updateProject(p.copy(stage = Stage.AWAITING_PLAN, currentRequest = text.trim()))
        system(pid, "Next: send the plan prompt to ${coord.name} and paste its JSON reply back.")
    }

    suspend fun importPlan(pid: Long, raw: String) {
        val p = project(pid)
        check(p.stage == Stage.AWAITING_PLAN) { "This project is not waiting for a plan." }
        val agents = dao.getAgents(pid)
        val coordinator = agents.firstOrNull { it.id == p.coordinatorAgentId } ?: throw IllegalStateException("The project has no coordinator.")
        val plan = when (val r = Parsers.parsePlan(raw)) {
            is ParseResult.Ok -> r.value
            is ParseResult.Err -> throw IllegalArgumentException("Could not read the plan: ${r.message}")
        }
        val ids = ArrayList<Long>()
        val summary = StringBuilder()
        if (plan.summary.isNotBlank()) summary.append(plan.summary).append("\n")
        plan.tasks.forEachIndexed { i, t ->
            val match = agents.firstOrNull { it.name.equals(t.agent, ignoreCase = true) }
            if (match == null) system(pid, "Unknown agent \"${t.agent}\" for \"${t.title}\" - assigned to ${coordinator.name}.")
            val worker = match ?: coordinator
            val deps = t.dependsOn.joinToString(",") { ids[it].toString() }
            ids.add(
                dao.insertTask(
                    TaskEntity(
                        projectId = pid, title = t.title, description = t.description, agentId = worker.id,
                        dependsOn = deps, context = p.currentRequest, status = TaskStatus.PENDING, createdAt = now()
                    )
                )
            )
            summary.append("${i + 1}. ${t.title} -> ${worker.name}\n")
        }
        msg(pid, MessageKind.COORDINATOR, coordinator.name, summary.toString().trim())
        dao.updateProject(p.copy(stage = Stage.EXECUTING))
        advance(pid)
    }

    // ---------- task flow ----------

    suspend fun markSent(taskId: Long) {
        val t = task(taskId)
        if (t.status != TaskStatus.ASSIGNED && t.status != TaskStatus.REQUIRES_REVISION) return
        val agent = dao.getAgent(t.agentId)
        dao.updateTask(t.copy(status = TaskStatus.AWAITING_RESPONSE, history = t.history.plusLine("Sent to ${agent?.name ?: "agent"}.")))
    }

    suspend fun importResult(taskId: Long, text: String) {
        require(text.isNotBlank()) { "Paste the response first." }
        val t = task(taskId)
        check(t.status == TaskStatus.ASSIGNED || t.status == TaskStatus.AWAITING_RESPONSE || t.status == TaskStatus.REQUIRES_REVISION) {
            "This task is not waiting for a response."
        }
        val agent = dao.getAgent(t.agentId)
        val clean = text.trim()
        dao.updateTask(t.copy(result = clean, status = TaskStatus.IN_PROGRESS, history = t.history.plusLine("Result received (attempt ${t.revisionCount + 1}).")))
        msg(t.projectId, MessageKind.AGENT, agent?.name ?: "Agent", clean, t.id)
        system(t.projectId, "Result for \"${t.title}\" received - review it.")
    }

    suspend fun approveTask(taskId: Long) {
        val t = task(taskId)
        check(t.status == TaskStatus.IN_PROGRESS || t.status == TaskStatus.FAILED || t.status == TaskStatus.REQUIRES_REVISION) {
            "This task cannot be approved now."
        }
        require(t.result.isNotBlank()) { "There is no result to approve." }
        complete(t, "Approved by you.")
    }

    suspend fun requestRevision(taskId: Long, feedback: String) {
        val t = task(taskId)
        check(t.status == TaskStatus.IN_PROGRESS) { "This task has no result to review." }
        revise(t, feedback.trim().ifBlank { "Please improve the result." })
    }

    suspend fun importReview(taskId: Long, raw: String) {
        val t = task(taskId)
        check(t.status == TaskStatus.IN_PROGRESS) { "This task has no result to review." }
        val review = when (val r = Parsers.parseReview(raw)) {
            is ParseResult.Ok -> r.value
            is ParseResult.Err -> throw IllegalArgumentException("Could not read the review: ${r.message}")
        }
        if (review.approved) complete(t, "Approved by the coordinator.") else revise(t, review.feedback)
    }

    suspend fun retryTask(taskId: Long) {
        val t = task(taskId)
        check(t.status == TaskStatus.FAILED) { "Only failed tasks can be retried." }
        dao.updateTask(t.copy(status = TaskStatus.ASSIGNED, revisionCount = 0, history = t.history.plusLine("Retried by you.")))
    }

    private suspend fun complete(t: TaskEntity, note: String) {
        dao.updateTask(t.copy(status = TaskStatus.COMPLETED, history = t.history.plusLine(note)))
        system(t.projectId, "\"${t.title}\" completed.")
        advance(t.projectId)
    }

    private suspend fun revise(t: TaskEntity, feedback: String) {
        val p = project(t.projectId)
        if (t.revisionCount >= p.maxRevisions) {
            dao.updateTask(t.copy(status = TaskStatus.FAILED, revisionNote = feedback, history = t.history.plusLine("Failed: revision limit (${p.maxRevisions}) reached.")))
            system(t.projectId, "\"${t.title}\" failed after ${p.maxRevisions} revision attempts. Last feedback: $feedback. You can retry it or approve its latest result.")
        } else {
            val n = t.revisionCount + 1
            dao.updateTask(t.copy(status = TaskStatus.REQUIRES_REVISION, revisionCount = n, revisionNote = feedback, history = t.history.plusLine("Revision $n requested: $feedback")))
            system(t.projectId, "Revision $n of ${p.maxRevisions} requested for \"${t.title}\".")
        }
    }

    /** Unlocks tasks whose dependencies are done; moves the project on when everything is complete. */
    private suspend fun advance(pid: Long) {
        val p = project(pid)
        if (p.stage != Stage.EXECUTING) return
        val tasks = dao.getTasks(pid)
        val byId = tasks.associateBy { it.id }
        for (t in tasks) {
            if (t.status == TaskStatus.PENDING && t.dependencyIds().all { byId[it]?.status == TaskStatus.COMPLETED }) {
                dao.updateTask(t.copy(status = TaskStatus.ASSIGNED, history = t.history.plusLine("Ready to send.")))
            }
        }
        val fresh = dao.getTasks(pid)
        if (fresh.isNotEmpty() && fresh.all { it.status == TaskStatus.COMPLETED }) {
            dao.updateProject(p.copy(stage = Stage.AWAITING_FINAL))
            system(pid, "All tasks are complete. Ask the coordinator for the final combined result.")
        }
    }

    suspend fun importFinal(pid: Long, text: String) {
        require(text.isNotBlank()) { "Paste the response first." }
        val p = project(pid)
        check(p.stage == Stage.AWAITING_FINAL) { "The project is not waiting for the final result." }
        val coord = dao.getAgent(p.coordinatorAgentId)
        msg(pid, MessageKind.FINAL, coord?.name ?: "Coordinator", text.trim())
        dao.updateProject(p.copy(stage = Stage.DONE))
        system(pid, "Request finished.")
    }

    // ---------- export ----------

    suspend fun exportText(pid: Long): String {
        val p = project(pid)
        return buildString {
            appendLine("AI CLUB export - ${p.name}")
            appendLine(p.objective)
            appendLine()
            dao.getMessages(pid).forEach { m ->
                appendLine("[${m.kind}] ${m.senderName}:")
                appendLine(m.text)
                appendLine()
            }
        }
    }
}
