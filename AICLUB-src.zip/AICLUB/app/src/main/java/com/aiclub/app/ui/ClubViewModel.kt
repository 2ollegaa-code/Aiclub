package com.aiclub.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.aiclub.app.data.ClubDao
import com.aiclub.app.data.ClubDb
import com.aiclub.app.data.ClubRepository
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ClubViewModel(app: Application) : AndroidViewModel(app) {
    val dao: ClubDao = ClubDb.get(app).dao()
    val repo = ClubRepository(dao)

    private val _toast = MutableSharedFlow<String>(extraBufferCapacity = 8)
    val toast = _toast.asSharedFlow()

    val projects = dao.observeProjects().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val allTasks = dao.observeAllTasks().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    /** Runs a repository action; errors become a snackbar message. */
    fun act(onSuccess: () -> Unit = {}, block: suspend () -> Unit) {
        viewModelScope.launch {
            try {
                block()
                onSuccess()
            } catch (e: Exception) {
                _toast.emit(e.message ?: "Something went wrong.")
            }
        }
    }

    fun createProject(name: String, objective: String, members: List<ClubRepository.NewMember>, coordinatorIndex: Int, onDone: (Long) -> Unit) {
        viewModelScope.launch {
            try {
                onDone(repo.createProject(name, objective, members, coordinatorIndex))
            } catch (e: Exception) {
                _toast.emit(e.message ?: "Could not create the project.")
            }
        }
    }
}
