package com.aiclub.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import java.io.File

object Launcher {
    fun copy(ctx: Context, text: String) {
        val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("AI CLUB", text))
    }

    fun isInstalled(ctx: Context, pkg: String?): Boolean =
        pkg != null && ctx.packageManager.getLaunchIntentForPackage(pkg) != null

    fun open(ctx: Context, pkg: String?): Boolean {
        if (pkg == null) return false
        val intent = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        return try {
            ctx.startActivity(intent)
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Shares a text file via FileProvider (avoids Binder size limits on long conversations). */
    fun shareText(ctx: Context, fileName: String, text: String) {
        val dir = File(ctx.cacheDir, "exports")
        dir.mkdirs()
        val file = File(dir, fileName)
        file.writeText(text)
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", file)
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val chooser = Intent.createChooser(send, "Export conversation").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(chooser)
    }
}
