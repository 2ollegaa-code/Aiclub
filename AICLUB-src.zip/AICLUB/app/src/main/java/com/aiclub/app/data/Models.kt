package com.aiclub.app.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

enum class Stage { IDLE, AWAITING_PLAN, EXECUTING, AWAITING_FINAL, DONE }

/** ASSIGNED = ready to send, AWAITING_RESPONSE = sent, IN_PROGRESS = result received and under review. */
enum class TaskStatus { PENDING, ASSIGNED, AWAITING_RESPONSE, IN_PROGRESS, REQUIRES_REVISION, COMPLETED, FAILED }

enum class MessageKind { USER, COORDINATOR, AGENT, SYSTEM, FINAL }

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val objective: String,
    val coordinatorAgentId: Long = 0,
    val stage: Stage = Stage.IDLE,
    val currentRequest: String = "",
    val maxRevisions: Int = 3,
    val createdAt: Long
)

@Entity(
    tableName = "agents",
    foreignKeys = [ForeignKey(entity = ProjectEntity::class, parentColumns = ["id"], childColumns = ["projectId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("projectId")]
)
data class AgentEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val projectId: Long,
    val appKey: String,
    val name: String,
    val role: String,
    val instructions: String = "",
    val receivesSharedResults: Boolean = true
)

@Entity(
    tableName = "messages",
    foreignKeys = [ForeignKey(entity = ProjectEntity::class, parentColumns = ["id"], childColumns = ["projectId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("projectId")]
)
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val projectId: Long,
    val kind: MessageKind,
    val senderName: String,
    val text: String,
    val replyToId: Long? = null,
    val taskId: Long? = null,
    val createdAt: Long
)

@Entity(
    tableName = "tasks",
    foreignKeys = [ForeignKey(entity = ProjectEntity::class, parentColumns = ["id"], childColumns = ["projectId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("projectId")]
)
data class TaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val projectId: Long,
    val title: String,
    val description: String,
    val agentId: Long,
    /** Comma-separated ids of tasks whose results this task waits for. */
    val dependsOn: String = "",
    val context: String = "",
    val sources: String = "",
    val status: TaskStatus = TaskStatus.PENDING,
    val result: String = "",
    val revisionCount: Int = 0,
    val revisionNote: String = "",
    val history: String = "",
    val createdAt: Long
)

fun TaskEntity.dependencyIds(): List<Long> = dependsOn.split(",").mapNotNull { it.trim().toLongOrNull() }
