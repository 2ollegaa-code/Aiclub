@file:OptIn(ExperimentalMaterial3Api::class)

package com.aiclub.app.ui

import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.AssistChip
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.aiclub.app.data.AgentEntity
import com.aiclub.app.data.ClubRepository
import com.aiclub.app.data.MessageEntity
import com.aiclub.app.data.MessageKind
import com.aiclub.app.data.ProjectEntity
import com.aiclub.app.data.Stage
import com.aiclub.app.data.TaskEntity
import com.aiclub.app.data.TaskStatus
import com.aiclub.app.data.dependencyIds
import com.aiclub.app.logic.KNOWN_APPS
import com.aiclub.app.logic.Prompts
import com.aiclub.app.logic.knownApp

@Composable
fun RoomScreen(vm: ClubViewModel, projectId: Long, onBack: () -> Unit) {
    val dao = vm.dao
    val project by remember(projectId) { dao.observeProject(projectId) }.collectAsState(initial = null)
    val agents by remember(projectId) { dao.observeAgents(projectId) }.collectAsState(initial = emptyList())
    val tasks by remember(projectId) { dao.observeTasks(projectId) }.collectAsState(initial = emptyList())
    val messages by remember(projectId) { dao.observeMessages(projectId) }.collectAsState(initial = emptyList())
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var showTeam by remember { mutableStateOf(false) }
    val ctx = LocalContext.current

    val p = project
    if (p == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Loading...") }
        return
    }
    val coordinator = agents.firstOrNull { it.id == p.coordinatorAgentId }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(p.name, maxLines = 1)
                        Text(stageLabel(p.stage), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                    }
                },
                navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back") } },
                actions = {
                    TextButton(onClick = { showTeam = true }) { Text("Team") }
                    IconButton(onClick = {
                        vm.act {
                            val text = vm.repo.exportText(projectId)
                            Launcher.shareText(ctx, "aiclub-${p.id}.txt", text)
                        }
                    }) { Icon(Icons.Default.Share, contentDescription = "Export conversation") }
                }
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            TabRow(selectedTabIndex = tab) {
                Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Chat") })
                Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Tasks (${tasks.size})") })
            }
            if (tab == 0) {
                ChatTab(vm, p, agents, tasks, messages, coordinator, goToTasks = { tab = 1 })
            } else {
                TasksTab(vm, p, agents, tasks)
            }
        }
    }
    if (showTeam) TeamDialog(vm, p, agents) { showTeam = false }
}

@Composable
private fun ChatTab(
    vm: ClubViewModel,
    p: ProjectEntity,
    agents: List<AgentEntity>,
    tasks: List<TaskEntity>,
    messages: List<MessageEntity>,
    coordinator: AgentEntity?,
    goToTasks: () -> Unit
) {
    val listState = rememberLazyListState()
    LaunchedEffect(messages.size, p.stage) { listState.animateScrollToItem(messages.size) }
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        state = listState,
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(messages, key = { it.id }) { MessageBubble(it) }
        item(key = "stage-panel") { StagePanel(vm, p, agents, tasks, coordinator, goToTasks) }
    }
}

@Composable
private fun MessageBubble(m: MessageEntity) {
    val scheme = MaterialTheme.colorScheme
    val container = when (m.kind) {
        MessageKind.USER -> scheme.primaryContainer
        MessageKind.FINAL -> scheme.secondaryContainer
        MessageKind.SYSTEM -> scheme.surface
        else -> scheme.surfaceVariant
    }
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = container)) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                if (m.kind == MessageKind.FINAL) "${m.senderName} - FINAL RESULT" else m.senderName,
                style = MaterialTheme.typography.labelSmall,
                color = scheme.primary
            )
            SelectionContainer { Text(m.text, style = MaterialTheme.typography.bodyMedium) }
        }
    }
}

@Composable
private fun StagePanel(
    vm: ClubViewModel,
    p: ProjectEntity,
    agents: List<AgentEntity>,
    tasks: List<TaskEntity>,
    coordinator: AgentEntity?,
    goToTasks: () -> Unit
) {
    val repo = vm.repo
    if (coordinator == null) {
        Text("This project has no coordinator. Open Team and choose one.")
        return
    }
    val app = knownApp(coordinator.appKey)
    when (p.stage) {
        Stage.IDLE, Stage.DONE -> {
            var req by remember { mutableStateOf("") }
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        if (p.stage == Stage.DONE) "Finished. Send a new task to ${coordinator.name}." else "Send your task to ${coordinator.name}.",
                        style = MaterialTheme.typography.titleSmall
                    )
                    OutlinedTextField(value = req, onValueChange = { req = it }, label = { Text("Task") }, minLines = 2, modifier = Modifier.fillMaxWidth())
                    Button(onClick = { vm.act(onSuccess = { req = "" }) { repo.submitRequest(p.id, req) } }, enabled = req.isNotBlank()) {
                        Text("Send to coordinator")
                    }
                }
            }
        }
        Stage.AWAITING_PLAN -> PromptStep(
            title = "Step: get the plan from ${coordinator.name}",
            hint = "Copy the prompt, paste it into ${app.label}, then paste its JSON reply below.",
            prompt = Prompts.plan(p, agents, coordinator, p.currentRequest),
            app = app,
            importLabel = "Paste ${coordinator.name}'s JSON plan",
            importButton = "Import plan",
            onSubmit = { text, ok -> vm.act(onSuccess = ok) { repo.importPlan(p.id, text) } }
        )
        Stage.EXECUTING -> Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("${tasks.count { it.status == TaskStatus.COMPLETED }} of ${tasks.size} tasks completed.", style = MaterialTheme.typography.titleSmall)
                Text("Open the Tasks tab for the next step.", style = MaterialTheme.typography.bodySmall)
                Button(onClick = goToTasks) { Text("Open tasks") }
            }
        }
        Stage.AWAITING_FINAL -> PromptStep(
            title = "Final step: ask ${coordinator.name} to combine everything",
            hint = "Copy the prompt, paste it into ${app.label}, then paste the final result below.",
            prompt = Prompts.finalResult(p, coordinator, tasks, agents),
            app = app,
            importLabel = "Paste the final result",
            importButton = "Import final result",
            onSubmit = { text, ok -> vm.act(onSuccess = ok) { repo.importFinal(p.id, text) } }
        )
    }
}

@Composable
private fun TasksTab(vm: ClubViewModel, p: ProjectEntity, agents: List<AgentEntity>, tasks: List<TaskEntity>) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        if (tasks.isEmpty()) item { Text("No tasks yet. They appear once the coordinator's plan is imported.") }
        items(tasks, key = { it.id }) { TaskCard(vm, p, it, tasks, agents) }
    }
}

@Composable
private fun TaskCard(vm: ClubViewModel, p: ProjectEntity, t: TaskEntity, tasks: List<TaskEntity>, agents: List<AgentEntity>) {
    val repo = vm.repo
    val coordinator = agents.firstOrNull { it.id == p.coordinatorAgentId }
    val worker = agents.firstOrNull { it.id == t.agentId } ?: coordinator
    var expanded by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(t.title, style = MaterialTheme.typography.titleSmall)
                    Text("${worker?.name ?: "(removed)"} - ${worker?.role ?: ""}", style = MaterialTheme.typography.bodySmall)
                }
                StatusChip(statusLabel(t.status))
            }
            if (t.revisionCount > 0) {
                Text("Revisions requested: ${t.revisionCount}/${p.maxRevisions}", style = MaterialTheme.typography.bodySmall)
            }
            TextButton(onClick = { expanded = !expanded }) { Text(if (expanded) "Hide details" else "Details") }
            if (expanded) {
                Text(t.description, style = MaterialTheme.typography.bodySmall)
                if (t.result.isNotBlank()) {
                    Text("Latest result", style = MaterialTheme.typography.labelMedium)
                    SelectionContainer { Text(t.result, style = MaterialTheme.typography.bodySmall) }
                }
                if (t.history.isNotBlank()) {
                    Text("History", style = MaterialTheme.typography.labelMedium)
                    Text(t.history, style = MaterialTheme.typography.bodySmall)
                }
            }
            when (t.status) {
                TaskStatus.PENDING -> {
                    val waiting = t.dependencyIds()
                        .mapNotNull { id -> tasks.firstOrNull { it.id == id } }
                        .filter { it.status != TaskStatus.COMPLETED }
                        .joinToString { it.title }
                    Text("Waiting for: $waiting", style = MaterialTheme.typography.bodySmall)
                }
                TaskStatus.ASSIGNED, TaskStatus.AWAITING_RESPONSE, TaskStatus.REQUIRES_REVISION -> {
                    if (worker != null) {
                        val app = knownApp(worker.appKey)
                        PromptStep(
                            title = if (t.revisionCount > 0 && t.revisionNote.isNotBlank()) "Revision: send back to ${worker.name}" else "Send to ${worker.name}",
                            hint = "Copy the prompt, paste it into ${app.label}, then paste its answer below.",
                            prompt = Prompts.forTask(p, worker, t, tasks, agents),
                            app = app,
                            importLabel = "Paste ${worker.name}'s answer",
                            importButton = "Import result",
                            onCopied = { vm.act { repo.markSent(t.id) } },
                            onSubmit = { text, ok -> vm.act(onSuccess = ok) { repo.importResult(t.id, text) } }
                        )
                    }
                }
                TaskStatus.IN_PROGRESS -> ReviewPanel(vm, p, t, coordinator, worker)
                TaskStatus.FAILED -> Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(onClick = { vm.act { repo.retryTask(t.id) } }) { Text("Retry") }
                    if (t.result.isNotBlank()) {
                        Button(onClick = { vm.act { repo.approveTask(t.id) } }) { Text("Approve latest result") }
                    }
                }
                TaskStatus.COMPLETED -> {}
            }
        }
    }
}

@Composable
private fun ReviewPanel(vm: ClubViewModel, p: ProjectEntity, t: TaskEntity, coordinator: AgentEntity?, assignee: AgentEntity?) {
    val repo = vm.repo
    var feedback by remember { mutableStateOf("") }
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Result received. Review it yourself or let the coordinator review it.", style = MaterialTheme.typography.bodySmall)
        Button(onClick = { vm.act { repo.approveTask(t.id) } }) { Text("Approve") }
        OutlinedTextField(value = feedback, onValueChange = { feedback = it }, label = { Text("What should be improved?") }, modifier = Modifier.fillMaxWidth())
        OutlinedButton(onClick = { vm.act(onSuccess = { feedback = "" }) { repo.requestRevision(t.id, feedback) } }) { Text("Request revision") }
        if (coordinator != null) {
            PromptStep(
                title = "Or let ${coordinator.name} review",
                hint = "Copy the review prompt, paste it into ${knownApp(coordinator.appKey).label}, then paste its JSON verdict.",
                prompt = Prompts.review(p, coordinator, assignee, t),
                app = knownApp(coordinator.appKey),
                importLabel = "Paste ${coordinator.name}'s JSON verdict",
                importButton = "Import review",
                onSubmit = { text, ok -> vm.act(onSuccess = ok) { repo.importReview(t.id, text) } }
            )
        }
    }
}

@Composable
private fun TeamDialog(vm: ClubViewModel, p: ProjectEntity, agents: List<AgentEntity>, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done") } },
        title = { Text("Team") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                agents.forEach { AgentEditor(vm, p, it) }
                Text("Add participant", style = MaterialTheme.typography.labelLarge)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    KNOWN_APPS.forEach { app ->
                        AssistChip(
                            onClick = { vm.act { vm.repo.addAgent(p.id, ClubRepository.NewMember(app.key, app.label, app.defaultRole)) } },
                            label = { Text(app.label) }
                        )
                    }
                }
            }
        }
    )
}

@Composable
private fun AgentEditor(vm: ClubViewModel, p: ProjectEntity, a: AgentEntity) {
    val repo = vm.repo
    var role by remember(a.id) { mutableStateOf(a.role) }
    var instructions by remember(a.id) { mutableStateOf(a.instructions) }
    var share by remember(a.id) { mutableStateOf(a.receivesSharedResults) }
    val isCoordinator = p.coordinatorAgentId == a.id
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(a.name, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f))
                if (isCoordinator) StatusChip("Coordinator") else {
                    TextButton(onClick = { vm.act { repo.setCoordinator(p.id, a.id) } }) { Text("Make coordinator") }
                }
            }
            OutlinedTextField(value = role, onValueChange = { role = it }, label = { Text("Role") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = instructions, onValueChange = { instructions = it }, label = { Text("Custom instructions") }, modifier = Modifier.fillMaxWidth())
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(checked = share, onCheckedChange = { share = it })
                Spacer(Modifier.width(8.dp))
                Text("Receives teammates' results", style = MaterialTheme.typography.bodySmall)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    vm.act { repo.updateAgent(a.copy(role = role.trim().ifBlank { a.role }, instructions = instructions.trim(), receivesSharedResults = share)) }
                }) { Text("Save") }
                if (!isCoordinator) {
                    TextButton(onClick = { vm.act { repo.removeAgent(a.id) } }) { Text("Remove") }
                }
            }
        }
    }
}
