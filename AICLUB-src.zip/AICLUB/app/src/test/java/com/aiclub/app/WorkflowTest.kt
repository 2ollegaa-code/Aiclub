package com.aiclub.app

import com.aiclub.app.data.ClubRepository
import com.aiclub.app.data.ClubRepository.NewMember
import com.aiclub.app.data.MessageKind
import com.aiclub.app.data.Stage
import com.aiclub.app.data.TaskStatus
import com.aiclub.app.logic.ParseResult
import com.aiclub.app.logic.Parsers
import com.aiclub.app.logic.Prompts
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Before
import org.junit.Test

class WorkflowTest {
    private lateinit var dao: FakeDao
    private lateinit var repo: ClubRepository
    private var clock = 1000L

    private val plan = """{"summary":"S","tasks":[
        {"title":"Research","description":"find facts","agent":"Perplexity","depends_on":[]},
        {"title":"Script","description":"write it","agent":"Claude","depends_on":[0]}]}"""

    @Before
    fun setup() {
        dao = FakeDao()
        repo = ClubRepository(dao) { clock++ }
    }

    private fun team() = listOf(
        NewMember("chatgpt", "ChatGPT", "Planner"),
        NewMember("claude", "Claude", "Writer"),
        NewMember("perplexity", "Perplexity", "Researcher")
    )

    private suspend fun started(): Long {
        val pid = repo.createProject("Sun video", "Explain", team(), 0)
        repo.submitRequest(pid, "Make a video about the Sun disappearing")
        repo.importPlan(pid, plan)
        return pid
    }

    private suspend fun expectFailure(block: suspend () -> Unit): String {
        try { block() } catch (e: Exception) { return e.message ?: "" }
        fail("Expected an error")
        return ""
    }

    @Test
    fun createProjectSetsCoordinatorAndUniqueNames() = runBlocking {
        val pid = repo.createProject("P", "O", listOf(NewMember("claude", "Claude", "A"), NewMember("claude", "Claude", "B")), 1)
        val agents = dao.getAgents(pid)
        assertEquals(listOf("Claude", "Claude 2"), agents.map { it.name })
        assertEquals(agents[1].id, dao.getProject(pid)!!.coordinatorAgentId)
    }

    @Test
    fun createProjectValidatesInput() = runBlocking {
        expectFailure { repo.createProject("", "o", team(), 0) }
        expectFailure { repo.createProject("P", "o", emptyList(), 0) }
        expectFailure { repo.createProject("P", "o", team(), -1) }
        Unit
    }

    @Test
    fun deleteProjectRemovesEverything() = runBlocking {
        val pid = started()
        repo.deleteProject(pid)
        assertTrue(dao.projects.isEmpty() && dao.agents.isEmpty() && dao.tasks.isEmpty() && dao.messages.isEmpty())
    }

    @Test
    fun addRemoveAndChangeCoordinator() = runBlocking {
        val pid = repo.createProject("P", "O", team(), 0)
        val newId = repo.addAgent(pid, NewMember("gemini", "Gemini", "Analyst"))
        assertEquals(4, dao.getAgents(pid).size)
        val coordId = dao.getProject(pid)!!.coordinatorAgentId
        expectFailure { repo.removeAgent(coordId) }
        repo.setCoordinator(pid, newId)
        assertEquals(newId, dao.getProject(pid)!!.coordinatorAgentId)
        repo.removeAgent(coordId)
        assertEquals(3, dao.getAgents(pid).size)
    }

    @Test
    fun removingAgentReassignsOpenTasks() = runBlocking {
        val pid = started()
        val perplexity = dao.getAgents(pid).first { it.name == "Perplexity" }
        repo.removeAgent(perplexity.id)
        val coord = dao.getProject(pid)!!.coordinatorAgentId
        assertEquals(coord, dao.getTasks(pid).first { it.title == "Research" }.agentId)
    }

    @Test
    fun planCreatesTasksAndRespectsDependencies() = runBlocking {
        val pid = started()
        val tasks = dao.getTasks(pid)
        assertEquals(TaskStatus.ASSIGNED, tasks[0].status)
        assertEquals(TaskStatus.PENDING, tasks[1].status)
        assertEquals(Stage.EXECUTING, dao.getProject(pid)!!.stage)
    }

    @Test
    fun fullWorkflowReachesFinalResult() = runBlocking {
        val pid = started()
        val t1 = dao.getTasks(pid)[0]
        repo.markSent(t1.id)
        assertEquals(TaskStatus.AWAITING_RESPONSE, dao.getTask(t1.id)!!.status)
        repo.importResult(t1.id, "RESULT-A")
        assertEquals(TaskStatus.IN_PROGRESS, dao.getTask(t1.id)!!.status)
        repo.importReview(t1.id, "Sure!\n```json\n{\"verdict\":\"approve\",\"feedback\":\"\"}\n```")
        val t2 = dao.getTasks(pid)[1]
        assertEquals(TaskStatus.ASSIGNED, t2.status)
        repo.importResult(t2.id, "RESULT-B")
        repo.approveTask(t2.id)
        assertEquals(Stage.AWAITING_FINAL, dao.getProject(pid)!!.stage)
        repo.importFinal(pid, "FINAL VIDEO SCRIPT")
        assertEquals(Stage.DONE, dao.getProject(pid)!!.stage)
        assertEquals(MessageKind.FINAL, dao.getMessages(pid).last { it.kind == MessageKind.FINAL }.kind)
    }

    @Test
    fun revisionsAreCappedAtThree() = runBlocking {
        val pid = started()
        val id = dao.getTasks(pid)[0].id
        for (i in 1..3) {
            repo.importResult(id, "draft $i")
            repo.requestRevision(id, "fix $i")
            assertEquals(TaskStatus.REQUIRES_REVISION, dao.getTask(id)!!.status)
            assertEquals(i, dao.getTask(id)!!.revisionCount)
        }
        repo.importResult(id, "draft 4")
        repo.requestRevision(id, "still bad")
        assertEquals(TaskStatus.FAILED, dao.getTask(id)!!.status)
        repo.retryTask(id)
        assertEquals(TaskStatus.ASSIGNED, dao.getTask(id)!!.status)
        assertEquals(0, dao.getTask(id)!!.revisionCount)
    }

    @Test
    fun dependencyResultsAreSharedOnlyWhenAllowed() = runBlocking {
        val pid = started()
        val t1 = dao.getTasks(pid)[0]
        repo.importResult(t1.id, "RESULT-A")
        repo.approveTask(t1.id)
        val project = dao.getProject(pid)!!
        val agents = dao.getAgents(pid)
        val t2 = dao.getTasks(pid)[1]
        val writer = agents.first { it.id == t2.agentId }
        assertTrue(Prompts.forTask(project, writer, t2, dao.getTasks(pid), agents).contains("RESULT-A"))
        val restricted = writer.copy(receivesSharedResults = false)
        assertFalse(Prompts.forTask(project, restricted, t2, dao.getTasks(pid), agents).contains("RESULT-A"))
    }

    @Test
    fun badPlanIsRejectedAndProjectKeepsWaiting() = runBlocking {
        val pid = repo.createProject("P", "O", team(), 0)
        repo.submitRequest(pid, "do it")
        expectFailure { repo.importPlan(pid, "I think we should research first.") }
        assertEquals(Stage.AWAITING_PLAN, dao.getProject(pid)!!.stage)
        assertTrue(dao.getTasks(pid).isEmpty())
    }

    @Test
    fun unknownAgentFallsBackToCoordinator() = runBlocking {
        val pid = repo.createProject("P", "O", team(), 0)
        repo.submitRequest(pid, "do it")
        repo.importPlan(pid, """{"tasks":[{"title":"X","description":"d","agent":"Nobody","depends_on":[]}]}""")
        assertEquals(dao.getProject(pid)!!.coordinatorAgentId, dao.getTasks(pid)[0].agentId)
    }

    @Test
    fun resultCannotBeImportedWhenNotWaiting() = runBlocking {
        val pid = started()
        val pending = dao.getTasks(pid)[1]
        expectFailure { repo.importResult(pending.id, "too early") }
        expectFailure { repo.importResult(dao.getTasks(pid)[0].id, "   ") }
        Unit
    }

    @Test
    fun secondRequestIsRejectedWhileBusy() = runBlocking {
        val pid = started()
        expectFailure { repo.submitRequest(pid, "another") }
        Unit
    }

    @Test
    fun parsersHandleFencesAndInvalidDependencies() {
        val ok = Parsers.parsePlan("Here you go:\n```json\n$plan\n```")
        assertTrue(ok is ParseResult.Ok)
        val bad = Parsers.parsePlan("""{"tasks":[{"title":"a","description":"","agent":"x","depends_on":[0]}]}""")
        assertTrue(bad is ParseResult.Err)
        assertTrue(Parsers.parseReview("{\"verdict\":\"maybe\"}") is ParseResult.Err)
        assertTrue(Parsers.parseReview("{\"verdict\":\"revise\",\"feedback\":\"x\"}") is ParseResult.Ok)
    }
}
