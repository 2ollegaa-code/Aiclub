package com.aiclub.app

import com.aiclub.app.data.AgentEntity
import com.aiclub.app.data.ClubDao
import com.aiclub.app.data.MessageEntity
import com.aiclub.app.data.ProjectEntity
import com.aiclub.app.data.TaskEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flowOf

/** In-memory stand-in for the Room DAO (simulates ON DELETE CASCADE). */
class FakeDao : ClubDao {
    val projects = mutableListOf<ProjectEntity>()
    val agents = mutableListOf<AgentEntity>()
    val messages = mutableListOf<MessageEntity>()
    val tasks = mutableListOf<TaskEntity>()
    private var seq = 0L
    private fun next(): Long { seq += 1; return seq }

    override fun observeProjects(): Flow<List<ProjectEntity>> = flowOf(projects.toList())
    override fun observeProject(id: Long): Flow<ProjectEntity?> = flowOf(projects.firstOrNull { it.id == id })
    override suspend fun getProject(id: Long): ProjectEntity? = projects.firstOrNull { it.id == id }
    override suspend fun insertProject(p: ProjectEntity): Long { val id = next(); projects.add(p.copy(id = id)); return id }
    override suspend fun updateProject(p: ProjectEntity) { val i = projects.indexOfFirst { it.id == p.id }; if (i >= 0) projects[i] = p }
    override suspend fun deleteProject(id: Long) {
        projects.removeAll { it.id == id }
        agents.removeAll { it.projectId == id }
        messages.removeAll { it.projectId == id }
        tasks.removeAll { it.projectId == id }
    }

    override fun observeAgents(pid: Long): Flow<List<AgentEntity>> = flowOf(agents.filter { it.projectId == pid })
    override suspend fun getAgents(pid: Long): List<AgentEntity> = agents.filter { it.projectId == pid }
    override suspend fun getAgent(id: Long): AgentEntity? = agents.firstOrNull { it.id == id }
    override suspend fun insertAgent(a: AgentEntity): Long { val id = next(); agents.add(a.copy(id = id)); return id }
    override suspend fun updateAgent(a: AgentEntity) { val i = agents.indexOfFirst { it.id == a.id }; if (i >= 0) agents[i] = a }
    override suspend fun deleteAgent(id: Long) { agents.removeAll { it.id == id } }

    override fun observeMessages(pid: Long): Flow<List<MessageEntity>> = flowOf(messages.filter { it.projectId == pid })
    override suspend fun getMessages(pid: Long): List<MessageEntity> = messages.filter { it.projectId == pid }
    override fun searchMessages(q: String): Flow<List<MessageEntity>> = flowOf(messages.filter { it.text.contains(q) })
    override suspend fun insertMessage(m: MessageEntity): Long { val id = next(); messages.add(m.copy(id = id)); return id }

    override fun observeTasks(pid: Long): Flow<List<TaskEntity>> = flowOf(tasks.filter { it.projectId == pid })
    override fun observeAllTasks(): Flow<List<TaskEntity>> = flowOf(tasks.toList())
    override suspend fun getTasks(pid: Long): List<TaskEntity> = tasks.filter { it.projectId == pid }
    override suspend fun getTask(id: Long): TaskEntity? = tasks.firstOrNull { it.id == id }
    override suspend fun insertTask(t: TaskEntity): Long { val id = next(); tasks.add(t.copy(id = id)); return id }
    override suspend fun updateTask(t: TaskEntity) { val i = tasks.indexOfFirst { it.id == t.id }; if (i >= 0) tasks[i] = t }
}
